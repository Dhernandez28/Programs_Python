#proyecto
from lifestore_file import lifestore_products,lifestore_sales, lifestore_searches
import os,time
print("***** Bienvenido a Lifestore ******* \n")
time.sleep(2) #congelacion del tiempo en ejecución 
os.system("clear") #limpiar pantalla 
cont =1 #variable del contador iniciando en 1
def menu():
  print("*********************************************************")
  print("* 1. -Reporte de los 50 productos con más ventas.       *") #mensaje de bienvenida
  print("* 2. -Reporte de los 100 productos con más busquedas.   *") #mensaje de bienvenida
  print("* 3. -Reporte de los 50 productos con menos ventas.     *")
  print("* 4. -Reporte de los 100 productos con menos busquedas. *")
  print("* 5. -Salir                                             *")
  print("*********************************************************") #mensaje de bienvenida

def mayores():
  lista=[]#[[idventa, producto, aux]]
  aux=0
  for articulos in lifestore_products: #iniciamos nuestro recorrido en products
    for ventas in lifestore_sales: # iniciamos recorrido en ventas
      if articulos[0] == ventas[1]: #si hay igual en los indices de las 2 listas
        aux +=1 #se realiza el incremento 

    plantilla=[articulos[0], articulos[1],aux] 
    lista.append((plantilla)) #agregamos la plantilla a la lista vacia
    aux = 0 #Reset 
   #algoritmo de ordenamiento aplicado listas
  mayor=[]
  while lista:
    minimo = lista[0][2] #determinar los indices
    lista_act = lista[0] #apartir de que indice
    for report in lista: #recorrido 
      if report[2] > minimo: #estblecemos el rango mayor o menor con el signo
        minimo = report[2] #iteracion para comparar y reasignar 
        lista_act=report #almacenar
    mayor.append(lista_act) #agregar
    lista.remove(lista_act) #remover

   #impresion de resultados [id product - 3 vecees]
  for reporte in mayor:
    if reporte[2] != 0:
      print ("El producto: ",reporte[1], " se vendio: ", reporte[2], "veces \n")

def bucar():
  lista=[]#[[idventa, producto, aux]]
  aux=0
  for articulos in lifestore_products: #iniciamos nuestro recorrido en products
    for ventas in lifestore_searches: # iniciamos recorrido en ventas
      if articulos[0] == ventas[1]: #si hay igual en los indices de las 2 listas
        aux +=1 #se realiza el incremento 

    plantilla=[articulos[0], articulos[1],aux] 
    lista.append((plantilla)) #agregamos la plantilla a la lista vacia
    aux = 0 #Reset 
  #algoritmo de ordenamiento aplicado listas
  mayor=[]
  while lista:
    minimo = lista[0][2] #determinar los indices
    lista_act = lista[0] #apartir de que indice
    for report in lista: #recorrido 
      if report[2] < minimo: #estblecemos el rango mayor o menor con el signo
        minimo = report[2] #iteracion para comparar y reasignar 
        lista_act=report #almacenar
    mayor.append(lista_act) #agregar
    lista.remove(lista_act) #remover
  aux1=0
  mayor.reverse()
  #impresion de resultados [id product - 3 vecees]
  for reporte in mayor:
    if reporte[2] != 0 and aux < 100:
      print ("El producto: ",reporte[1], " se buscó: ", reporte[2], "veces \n")
    
    aux1 +=1

def menores():
  lista=[]#[[id producto, categoria, aux]]
  aux=0
  aux1=0

  for articulos in lifestore_products: #iniciamos nuestro recorrido en products
    for ventas in lifestore_sales: # iniciamos recorrido en ventas
      if articulos[0] == ventas[1]: #si hay igual en los indices de las 2 listas
        aux +=1 #se realiza el incremento 
    plantilla=[articulos[0], articulos[1], articulos[3],aux] 
    lista.append((plantilla)) #agregamos la plantilla a la lista vacia
    aux = 0 #Reset 
  #print(plantilla)#muestra como quedo la lista
  #algoritmo de ordenamiento aplicado listas

  mayor=[]
  while lista:
    minimo = lista[0][3] #determinar los indices
    lista_act = lista[0] #apartir de que indice
    for report in lista: #recorrido 
      if report[3] < minimo: #estblecemos el rango mayor o menor con el signo
        minimo = report[3] #iteracion para comparar y reasignar 
        lista_act=report #almacenar
    mayor.append(lista_act) #agregar
    lista.remove(lista_act) #remover

    #impresion de resultados [id product - 3 vecees]
  for reporte in mayor:
    if reporte[3] != 0 and aux1 < 50:
      print ("El producto: ",reporte[0],"de la categoria",reporte[2] ," se vendio: ",reporte[3],  "veces ")
      aux+=1

def busqueda():
  lista=[]#[[idventa, producto, categoria, aux]]
  aux=0

  for articulos in lifestore_products: #iniciamos nuestro recorrido en products
    for ventas in lifestore_searches: # iniciamos recorrido en ventas
      if articulos[0] == ventas[1]: #si hay igual en los indices de las 2 listas
        aux +=1 #se realiza el incremento 

    plantilla=[articulos[0], articulos[1],articulos[3],aux] 
    lista.append((plantilla)) #agregamos la plantilla a la lista vacia
    aux = 0 #Reset 
  #algoritmo de ordenamiento aplicado listas
  mayor=[]
  while lista:
    minimo = lista[0][3] #determinar los indices
    lista_act = lista[0] #apartir de que indice
    for report in lista: #recorrido 
      if report[3] < minimo: #estblecemos el rango mayor o menor con el signo
        minimo = report[3] #iteracion para comparar y reasignar 
        lista_act=report #almacenar
    mayor.append(lista_act) #agregar
    lista.remove(lista_act) #remover
  aux1=0
  #impresion de resultados [id product - 3 vecees]
  for reporte in mayor:
    if reporte[3] != 0 and aux < 100:
      print ("El producto: ",reporte[0],"de la categoria",reporte[2]," obtuvo ", reporte[3], "busquedas \n")
    
    aux1 +=1

while cont <= 3: # decimos que mientras que el contador no supere esta condicdion 
  usuario = input("User: ")#pedimos datos al usuario
  contraseña = input("Contraseña: ")
  if usuario == "Sistemas" and contraseña == "SISTEMAS": #establecemos variables y evaluamos
    os.system("clear")
    print("*********************************************************")
    print("* 1. -Reporte de los 50 productos con más ventas.       *") #mensaje de bienvenida
    print("* 2. -Reporte de los 100 productos con más busquedas.   *") #mensaje de bienvenida
    print("* 3. -Reporte de los 50 productos con menos ventas.     *")
    print("* 4. -Reporte de los 100 productos con menos busquedas. *")
    print("* 5. -Salir del programa.                               *")
    print("*********************************************************") #mensaje de bienvenida
    while True:
      opc=input("\n Ingrese un numero correspondiente al menú ->  ")
      if opc == '1':
        os.system("clear")
        menu()
        mayores()
      elif opc == '2':
        os.system("clear")
        menu()
        bucar()
      elif opc == '3':
        os.system("clear")
        menu()
        menores()
      elif opc == '4':
        os.system("clear")
        menu()
        busqueda()
      elif opc == '5':
        os.system("clear")
        break
      else:
        print("Opción incorrecta")
    cont = 4 # se asigno al  contador un valor superior para dar salida al bucle
  else: #de lo contrario se visualiza mensaje de intentos fallidos
    print("Acceso Erroneo ")
    print("Intento", cont ,"Pruebe de nuevo porfavor!")
    time.sleep(2)
    os.system("clear")
    if cont == 3:
      print("Supero el limite de intentos ")
      print("Consulte a su administrador ")
      time.sleep(2)
      os.system("clear")
      break
    cont = cont +1 # cada iteracion se aumenta para validar la condicion establecida

    

